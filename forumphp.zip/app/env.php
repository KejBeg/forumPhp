<?php
const APP_NAME = 'forumPhP';

const DB_HOST = 'localhost';
const DB_USER = 'forumPhp';
const DB_PASS = 'forumPhp';
const DB_DATABASE = 'forumPhp';
const DB_PORT = 3306;

const JWT_SECRET = 'abbd8ec60ac801b3b26475c22b82a257b05868a59f7d1022f38ca15e35d26a18';

