<?php
require_once API . '/BaseController.php';

class MessageController extends BaseController
{
	public function __construct() {
		parent::__construct();
	}
}
