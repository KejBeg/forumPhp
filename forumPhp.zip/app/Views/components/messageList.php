<div class="message-list-container">
	<ul></ul>
</div>

<script>
		fetchMessages();
		setInterval(fetchMessages, 5000);

</script>
